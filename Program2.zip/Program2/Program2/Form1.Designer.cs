﻿namespace Program2
{
    partial class program2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.creditHoursLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.lastNameTB = new System.Windows.Forms.TextBox();
            this.registrationButton = new System.Windows.Forms.Button();
            this.freshmanRB = new System.Windows.Forms.RadioButton();
            this.sophomoreRB = new System.Windows.Forms.RadioButton();
            this.juniorRB = new System.Windows.Forms.RadioButton();
            this.seniorRB = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // creditHoursLabel
            // 
            this.creditHoursLabel.AutoSize = true;
            this.creditHoursLabel.Location = new System.Drawing.Point(42, 9);
            this.creditHoursLabel.Name = "creditHoursLabel";
            this.creditHoursLabel.Size = new System.Drawing.Size(0, 13);
            this.creditHoursLabel.TabIndex = 0;
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(2, 9);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(61, 13);
            this.lastNameLabel.TabIndex = 2;
            this.lastNameLabel.Text = "Last Name:";
            // 
            // lastNameTB
            // 
            this.lastNameTB.Location = new System.Drawing.Point(69, 6);
            this.lastNameTB.Name = "lastNameTB";
            this.lastNameTB.Size = new System.Drawing.Size(135, 20);
            this.lastNameTB.TabIndex = 3;
            this.lastNameTB.TextChanged += new System.EventHandler(this.lastNameTB_TextChanged);
            // 
            // registrationButton
            // 
            this.registrationButton.Location = new System.Drawing.Point(5, 125);
            this.registrationButton.Name = "registrationButton";
            this.registrationButton.Size = new System.Drawing.Size(199, 28);
            this.registrationButton.TabIndex = 4;
            this.registrationButton.Text = "Click Here for your Registration Time!";
            this.registrationButton.UseVisualStyleBackColor = true;
            this.registrationButton.Click += new System.EventHandler(this.registrationButton_Click);
            // 
            // freshmanRB
            // 
            this.freshmanRB.AutoSize = true;
            this.freshmanRB.Location = new System.Drawing.Point(69, 32);
            this.freshmanRB.Name = "freshmanRB";
            this.freshmanRB.Size = new System.Drawing.Size(71, 17);
            this.freshmanRB.TabIndex = 5;
            this.freshmanRB.TabStop = true;
            this.freshmanRB.Text = "Freshman";
            this.freshmanRB.UseVisualStyleBackColor = true;
            // 
            // sophomoreRB
            // 
            this.sophomoreRB.AutoSize = true;
            this.sophomoreRB.Location = new System.Drawing.Point(69, 55);
            this.sophomoreRB.Name = "sophomoreRB";
            this.sophomoreRB.Size = new System.Drawing.Size(79, 17);
            this.sophomoreRB.TabIndex = 6;
            this.sophomoreRB.TabStop = true;
            this.sophomoreRB.Text = "Sophomore";
            this.sophomoreRB.UseVisualStyleBackColor = true;
            // 
            // juniorRB
            // 
            this.juniorRB.AutoSize = true;
            this.juniorRB.Location = new System.Drawing.Point(69, 78);
            this.juniorRB.Name = "juniorRB";
            this.juniorRB.Size = new System.Drawing.Size(53, 17);
            this.juniorRB.TabIndex = 7;
            this.juniorRB.TabStop = true;
            this.juniorRB.Text = "Junior";
            this.juniorRB.UseVisualStyleBackColor = true;
            this.juniorRB.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // seniorRB
            // 
            this.seniorRB.AutoSize = true;
            this.seniorRB.Location = new System.Drawing.Point(69, 101);
            this.seniorRB.Name = "seniorRB";
            this.seniorRB.Size = new System.Drawing.Size(55, 17);
            this.seniorRB.TabIndex = 8;
            this.seniorRB.TabStop = true;
            this.seniorRB.Text = "Senior";
            this.seniorRB.UseVisualStyleBackColor = true;
            // 
            // program2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(208, 158);
            this.Controls.Add(this.seniorRB);
            this.Controls.Add(this.juniorRB);
            this.Controls.Add(this.sophomoreRB);
            this.Controls.Add(this.freshmanRB);
            this.Controls.Add(this.registrationButton);
            this.Controls.Add(this.lastNameTB);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.creditHoursLabel);
            this.Name = "program2";
            this.Text = "Program 2";
            this.Load += new System.EventHandler(this.program2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label creditHoursLabel;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.TextBox lastNameTB;
        private System.Windows.Forms.Button registrationButton;
        private System.Windows.Forms.RadioButton freshmanRB;
        private System.Windows.Forms.RadioButton sophomoreRB;
        private System.Windows.Forms.RadioButton juniorRB;
        private System.Windows.Forms.RadioButton seniorRB;
    }
}

