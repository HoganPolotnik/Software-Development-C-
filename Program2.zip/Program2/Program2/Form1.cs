﻿// Grading ID: A2458
// Program 2
// 22 OCT 17
// CIS199-01
// Program will determine time and date of registration for students based on year in school and last name

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class program2 : Form
    {
        public program2()
        {
            InitializeComponent();
        }

        

        private void registrationButton_Click(object sender, EventArgs e)
        {
            //constant variables for times declared 
            const string TIME_SLOT1 = " at 8:30 AM";
            const string TIME_SLOT2 = " at 10:00 AM";
            const string TIME_SLOT3 = " at 11:30 AM";
            const string TIME_SLOT4 = " at 2:00 PM";
            const string TIME_SLOT5 = " at 4:00 PM";

            //constant variables for dates declared
            const string DAY1 = " 3rd of November";
            const string DAY2 = " 6th of November";
            const string DAY3 = " 7th of November";
            const string DAY4 = " 8th of November";
            const string DAY5 = " 9th of November";
            const string DAY6 = " 10th of November";

           
           
            string lastName; // will hold the student's last name
            char letter; // will hold the first letter of the student's last name to determine time of registration

            //declare the variable that will hold result message
            string registrationTime = "You Need to Register on the";

            // parse input textboxes 
            lastName = lastNameTB.Text;
            letter = char.ToUpper(lastName[0]); //take the first letter of the last name and convert it to upper case

             
            {
              // program execution
                
                    if (seniorRB.Checked) // testing to see if student is a senior
                    {
                        if (letter >= 'T' && letter < 'Z')
                            MessageBox.Show(registrationTime + DAY1 + TIME_SLOT1);
                        else if (letter >= 'A' && letter <= 'D')
                            MessageBox.Show(registrationTime + DAY1 + TIME_SLOT2);
                        else if (letter >= 'E' && letter <= 'I')
                            MessageBox.Show(registrationTime + DAY1 + TIME_SLOT3);
                        else if (letter >= 'J' && letter <= 'O')
                            MessageBox.Show(registrationTime + DAY1 + TIME_SLOT4);
                        else if (letter >= 'P' && letter <= 'S')
                            MessageBox.Show(registrationTime + DAY1 + TIME_SLOT5);
                    }
                    else if (juniorRB.Checked) // if not a senior, testing to see if student is a junior
                    {
                        if (letter >= 'T' && letter <= 'Z')
                            MessageBox.Show(registrationTime + DAY2 + TIME_SLOT1);
                        else if (letter >= 'A' && letter <= 'D')
                            MessageBox.Show(registrationTime + DAY2 + TIME_SLOT2);
                        else if (letter >= 'E' && letter <= 'I')
                            MessageBox.Show(registrationTime + DAY2 + TIME_SLOT3);
                        else if (letter >= 'J' && letter <= 'O')
                            MessageBox.Show(registrationTime + DAY2 + TIME_SLOT4);
                        else if (letter >= 'P' && letter <= 'S')
                            MessageBox.Show(registrationTime + DAY2 + TIME_SLOT5);
                    }
                    else if (sophomoreRB.Checked) // if not a junior, testing to see if student is a sophomore
                    {
                        if (letter >= 'T' && letter <= 'V')
                            MessageBox.Show(registrationTime + DAY3 + TIME_SLOT1);
                        else if (letter >= 'W' && letter <= 'Z')
                            MessageBox.Show(registrationTime + DAY3 + TIME_SLOT2);
                        else if (letter >= 'A' && letter <= 'B')
                            MessageBox.Show(registrationTime + DAY3 + TIME_SLOT3);
                        else if (letter >= 'C' && letter <= 'D')
                            MessageBox.Show(registrationTime + DAY3 + TIME_SLOT4);
                        else if (letter >= 'E' && letter <= 'F')
                            MessageBox.Show(registrationTime + DAY3 + TIME_SLOT5);
                        else if (letter >= 'G' && letter <= 'I')
                            MessageBox.Show(registrationTime + DAY4 + TIME_SLOT1);
                        else if (letter >= 'J' && letter <= 'L')
                            MessageBox.Show(registrationTime + DAY4 + TIME_SLOT2);
                        else if (letter >= 'M' && letter <= 'O')
                            MessageBox.Show(registrationTime + DAY4 + TIME_SLOT3);
                        else if (letter >= 'P' && letter <= 'Q')
                            MessageBox.Show(registrationTime + DAY4 + TIME_SLOT4);
                        else if (letter >= 'R' && letter <= 'S')
                            MessageBox.Show(registrationTime + DAY4 + TIME_SLOT5);
                    }
                    else // all other input values must mean the student is a freshman
                    {
                        if (letter >= 'T' && letter <= 'V')
                            MessageBox.Show(registrationTime + DAY5 + TIME_SLOT1);
                        else if (letter >= 'W' && letter <= 'Z')
                            MessageBox.Show(registrationTime + DAY5 + TIME_SLOT2);
                        else if (letter >= 'A' && letter <= 'B')
                            MessageBox.Show(registrationTime + DAY5 + TIME_SLOT3);
                        else if (letter >= 'C' && letter <= 'D')
                            MessageBox.Show(registrationTime + DAY5 + TIME_SLOT4);
                        else if (letter >= 'E' && letter <= 'F')
                            MessageBox.Show(registrationTime + DAY5 + TIME_SLOT5);
                        else if (letter >= 'G' && letter <= 'I')
                            MessageBox.Show(registrationTime + DAY6 + TIME_SLOT1);
                        else if (letter >= 'J' && letter <= 'L')
                            MessageBox.Show(registrationTime + DAY6 + TIME_SLOT2);
                        else if (letter >= 'M' && letter <= 'O')
                            MessageBox.Show(registrationTime + DAY6 + TIME_SLOT3);
                        else if (letter >= 'P' && letter <= 'Q')
                            MessageBox.Show(registrationTime + DAY6 + TIME_SLOT4);
                        else if (letter >= 'R' && letter <= 'S')
                            MessageBox.Show(registrationTime + DAY6 + TIME_SLOT5);
                    }

                
                
            }
          

        }

        

        private void lastNameTB_TextChanged(object sender, EventArgs e)
        {

        }

        private void program2_Load(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
