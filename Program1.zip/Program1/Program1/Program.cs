﻿// Grading ID: A2458
// Program 1
// 26 September 17
// CIS199-01

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program1
{
    class Program
    {
        static void Main(string[] args)
        {
            string lengthOfWalls; // length of walls in feet
            string heightOfWalls; // height of walls in feet
            string numberOfDoors; // number of doors in room
            string numberOfWindows; // number of windows in room
            string numberOfCoats; // number of paint coats needed
            double wallLength; // length of walls as number
            double wallHeight; // height of walls as a number
            const int doors = 20; // constant footage of door
			const int windows = 15; // constant footage of window
            int coats; // coats needed as number
            double minGal; // minumum gallons of paint needed
			double totalGal; // total gallons of paint needed
			double squareFeet; //length and height of walls
			double sum; // length and height of walls together
			double totalSf; // square footage with windows and doors subtracted
			const int can = 350; // footage of pait per gallon
			double totalDoors; // number of doors user inserted multiplied by footage
			double totalWindows; // number of windows inserted multiplied by footage

			// writelines defined
			Console.WriteLine("Welcome to the Handy - Dandy Paint Estimator");
            Console.WriteLine("");

            Console.Write("Enter the total length of all walls (in feet): "); 
            lengthOfWalls = Console.ReadLine();  
            wallLength = double.Parse(lengthOfWalls);

            Console.Write("Enter the height of the walls (in feet): ");
            heightOfWalls = Console.ReadLine();
            wallHeight = double.Parse(heightOfWalls);

            Console.Write("Enter the number of doors (non-neg int): ");
            numberOfDoors = Console.ReadLine();
			totalDoors = double.Parse(numberOfDoors);

            Console.Write("Enter the number of windows (non-neg int): ");
            numberOfWindows = Console.ReadLine();
			totalWindows = double.Parse(numberOfWindows);

            Console.Write("Enter the number of coats of paint (non-neg int): ");
            numberOfCoats = Console.ReadLine();
			coats = int.Parse(numberOfCoats);
			
			//calculations defined
			totalDoors = totalDoors * doors;
			totalWindows = totalWindows * windows;
			squareFeet = wallLength * wallHeight;
			sum = squareFeet - totalWindows - totalDoors;
			totalSf = sum * coats;
			minGal = totalSf / can;

			totalGal = (int)Math.Ceiling(minGal);



			// output
			Console.WriteLine(" ");
            Console.WriteLine($"You need a minumum of {minGal:F1} gallons of paint");
            Console.WriteLine($"You'll need to buy {totalGal} gallons, though");



        }
    }
}
