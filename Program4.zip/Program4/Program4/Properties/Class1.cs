﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4.Properties
{
    class Class1
    {
        static void Main() //lists five books as objects with all information about the book to be displayed once pulled 
        {
            LibraryBook object0 = new LibraryBook("Travel", "Polo", "Howell", 2009, "122");
            LibraryBook object1 = new LibraryBook("Travel Here", "Polo", "Howell", 2010, "123");
            LibraryBook object2 = new LibraryBook("Travel Far", "Polo", "Howell", 2011, "124");
            LibraryBook object3 = new LibraryBook("Travel Near", "Polo", "Howell", 2012, "125");
            LibraryBook object4 = new LibraryBook("Travel Abroad", "Polo", "Howell", 2013, "126");

            LibraryBook[] program = new LibraryBook[5];

            program[0] = object0; //describes books as objects 
            program[1] = object1;
            program[2] = object2;
            program[3] = object3;
            program[4] = object4;

            foreach (LibraryBook firstBook in program) //pulls first book into list 
            {
                Console.WriteLine(firstBook);
                Console.WriteLine();
            }

        }
    }
}
