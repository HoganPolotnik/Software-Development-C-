﻿//Grading ID: A2458
//Program 4
//5 December 2017
//CIS199-01
//This program explores the creation of a reusable class and separate GUI application that creates a list objects

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    public class LibraryBook //first class creation
    {
        public string titleString; //title variable 
        public string authorString; //author variable
        public string publisherString; //publisher variable 
        public int copyrightInt; //copyright variable 
        public string callNumberString; //call number variable 

        public LibraryBook(string title = " ", string author = " ", string publisher = " ", int copyright = 2017, string callNumber = " ")
        {
            chosenBook(title, author, publisher, copyright, callNumber); //lists the books information 
        }

        public void chosenBook(string title, string author, string publisher, int copyright, string callNumber) //lists the chosen books information
        {
            Title = title;
            Author = author;
            Publisher = publisher;
            CopyrightYr = copyright;
            CallNumber = callNumber;

        }

        public string Title //returns book title 
        {
            get
            {
                return titleString;
            }
            private set
            {
                titleString = value;
            }
        }
        public string Author //returns book author 
        {
            get
            {
                return authorString;
            }
            private set
            {
                authorString = value;
            }
        }
        public string Publisher //returns book publisher 
        {
            get
            {
                return publisherString;
            }
            private set
            {
                publisherString = value;
            }
        }
        public int CopyrightYr //returns the copyright year of the book
        {
            get
            {
                return copyrightInt;
            }
            private set
            {
                if (value > 0) copyrightInt = value;
                else copyrightInt = 0;
            }
        }
        public string CallNumber //returns the call number of the book
        {
            get
            {
                return callNumberString;
            }
            set
            {
                callNumberString = value;
            }
        }

        bool status;
        public void CheckOut() //states whether or not the book is checked out 
        {
            status = true;
        }
        public void ReturnToShelf()
        {
            status = false;
        }
        public bool IsCheckedOut
        {
            get
            {
                return status;
            }
            set
            {
                if (status == true) IsCheckedOut = true; //will return status of book
                else IsCheckedOut = false;
            }
        
        }

        public override string ToString()
        {
            string result;
            result = "Title: " + Title + System.Environment.NewLine + "Author: " + Author + System.Environment.NewLine + "Publisher: " + Publisher + System.Environment.NewLine + 
                "Copyright Yr: " + CopyrightYr + System.Environment.NewLine + "Call Number: " + CallNumber + System.Environment.NewLine + "Is Checked Out: " + IsCheckedOut.ToString();
            return result;
            //able to pull information into a neat layout stating all information on book
        }
    }
}
